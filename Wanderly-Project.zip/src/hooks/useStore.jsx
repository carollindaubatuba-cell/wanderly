import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { KEYS, readJSON, writeJSON, removeKey, loadTrips, loadSettings } from '../utils/storage.js';
import { makeTrip, cloneTrip, clearedTripData } from '../data/defaults.js';
import { buildDemoTrip } from '../data/demo.js';
import { reconcileTrip } from '../utils/calc.js';
import { parseImport, downloadJSON, buildExport, safeFileName } from '../utils/io.js';
import { uid, nowISO } from '../utils/ids.js';

const Ctx = createContext(null);
export const useStore = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore must be used inside StoreProvider');
  return v;
};

export const ROUTES = [
  'overview', 'trips', 'trip', 'itinerary', 'budget', 'bookings', 'packing',
  'places', 'notes', 'documents', 'emergency', 'tripsettings', 'settings',
];
const readRoute = () => {
  const h = window.location.hash.replace(/^#\/?/, '').split('?')[0];
  return ROUTES.includes(h) ? h : 'overview';
};

export function StoreProvider({ children }) {
  const [trips, setTrips] = useState(loadTrips);
  const [settings, setSettingsState] = useState(loadSettings);
  const [currentId, setCurrentId] = useState(() => {
    const v = readJSON(KEYS.current);
    return typeof v === 'string' ? v : null;
  });
  const [route, setRoute] = useState(readRoute);
  const [toasts, setToasts] = useState([]);
  const [storageError, setStorageError] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [tripModal, setTripModal] = useState({ open: false, trip: null });
  const [searchOpen, setSearchOpen] = useState(false);

  /* ---------- derived ---------- */
  const trip = useMemo(() => {
    if (!trips.length) return null;
    return (
      trips.find((t) => t.id === currentId) ||
      [...trips].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))[0]
    );
  }, [trips, currentId]);
  const tripRef = useRef(trip);
  tripRef.current = trip;
  const tripsRef = useRef(trips);
  tripsRef.current = trips;

  /* ---------- toasts ---------- */
  const dismissToast = useCallback((id) => setToasts((p) => p.filter((t) => t.id !== id)), []);
  const toast = useCallback((message, type = 'success') => {
    const id = uid();
    setToasts((p) => [...p.slice(-2), { id, message, type }]);
    setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), 3800);
  }, []);

  /* ---------- persistence ---------- */
  const prevTrips = useRef(trips);
  const firstRun = useRef(true);
  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    const changed = prevTrips.current !== trips;
    prevTrips.current = trips;
    if (settings.autoSave) {
      if (changed || dirty) {
        setStorageError(!writeJSON(KEYS.trips, trips));
        setDirty(false);
      }
    } else if (changed) {
      setDirty(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trips, settings.autoSave]);

  const saveNow = useCallback(() => {
    setStorageError(!writeJSON(KEYS.trips, trips));
    setDirty(false);
    toast('Saved on this device');
  }, [trips, toast]);

  useEffect(() => {
    writeJSON(KEYS.settings, settings);
    document.documentElement.setAttribute('data-theme', settings.theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', settings.theme === 'dark' ? '#171917' : '#F7F7F5');
  }, [settings]);

  useEffect(() => {
    if (currentId) writeJSON(KEYS.current, currentId);
    else removeKey(KEYS.current);
  }, [currentId]);

  /* ---------- routing ---------- */
  useEffect(() => {
    const onHash = () => setRoute(readRoute());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [route]);
  const navigate = useCallback((r) => {
    try {
      window.location.hash = `/${r}`;
    } catch {
      /* ignore */
    }
    setRoute(r);
  }, []);

  /* ---------- settings ---------- */
  const setSettings = useCallback((patch) => setSettingsState((s) => ({ ...s, ...patch })), []);

  /* ---------- trips ---------- */
  const updateTrip = useCallback((id, patch) => {
    setTrips((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const p = typeof patch === 'function' ? patch(t) : patch;
        return reconcileTrip({ ...t, ...p, updatedAt: nowISO() });
      })
    );
  }, []);

  const createTrip = useCallback((fields) => {
    const t = makeTrip(fields);
    setTrips((p) => [t, ...p]);
    setCurrentId(t.id);
    return t;
  }, []);

  const openTrip = useCallback(
    (id, to = 'trip') => {
      setCurrentId(id);
      navigate(to);
    },
    [navigate]
  );

  const deleteTrip = useCallback(
    (id) => {
      setTrips((p) => p.filter((t) => t.id !== id));
      setCurrentId((c) => (c === id ? null : c));
    },
    []
  );

  const duplicateTrip = useCallback((id) => {
    const t = tripsRef.current.find((x) => x.id === id);
    if (!t) return null;
    const copy = cloneTrip(t);
    setTrips((p) => [copy, ...p]);
    return copy;
  }, []);

  const clearTripData = useCallback((id) => updateTrip(id, (t) => clearedTripData(t)), [updateTrip]);

  const clearAll = useCallback(() => {
    setTrips([]);
    setCurrentId(null);
  }, []);

  /* ---------- list helpers for the current trip ---------- */
  const patchTrip = useCallback(
    (fn) => {
      const t = tripRef.current;
      if (t) updateTrip(t.id, fn);
    },
    [updateTrip]
  );
  const upsert = useCallback(
    (key, item) =>
      patchTrip((t) => {
        const list = t[key];
        return { [key]: list.some((x) => x.id === item.id) ? list.map((x) => (x.id === item.id ? item : x)) : [...list, item] };
      }),
    [patchTrip]
  );
  const remove = useCallback((key, id) => patchTrip((t) => ({ [key]: t[key].filter((x) => x.id !== id) })), [patchTrip]);

  /* ---------- demo ---------- */
  const demoExists = trips.some((t) => t.isDemo);
  const openDemo = useCallback(() => {
    const existing = trips.find((t) => t.isDemo);
    if (existing) {
      openTrip(existing.id);
      return;
    }
    const d = buildDemoTrip();
    setTrips((p) => [d, ...p]);
    setCurrentId(d.id);
    navigate('trip');
  }, [trips, openTrip, navigate]);

  const resetDemo = useCallback(() => {
    const d = buildDemoTrip();
    setTrips((p) => [d, ...p.filter((t) => !t.isDemo)]);
    setCurrentId(d.id);
    toast('Demo trip reset');
  }, [toast]);

  /* ---------- import / export ---------- */
  const importText = useCallback(
    (text, size) => {
      try {
        const imported = parseImport(text, size);
        setTrips((p) => [...imported, ...p]);
        setCurrentId(imported[0].id);
        return { ok: true, count: imported.length };
      } catch (e) {
        return { ok: false, error: e.message || 'That file could not be imported.' };
      }
    },
    []
  );
  const exportTrip = useCallback(
    (id) => {
      const t = trips.find((x) => x.id === id);
      if (!t) return false;
      return downloadJSON(`wanderly-${safeFileName(t.name)}.json`, buildExport([t]));
    },
    [trips]
  );
  const exportAll = useCallback(() => downloadJSON('wanderly-backup.json', buildExport(trips)), [trips]);

  /* ---------- modals ---------- */
  const openTripModal = useCallback((t = null) => setTripModal({ open: true, trip: t }), []);
  const closeTripModal = useCallback(() => setTripModal({ open: false, trip: null }), []);

  const value = useMemo(
    () => ({
      trips, trip, settings, route, toasts, storageError, dirty, tripModal, searchOpen,
      demoExists,
      navigate, setSettings, toast, dismissToast, saveNow,
      createTrip, updateTrip, openTrip, deleteTrip, duplicateTrip, clearTripData, clearAll,
      patchTrip, upsert, remove,
      openDemo, resetDemo, importText, exportTrip, exportAll,
      openTripModal, closeTripModal, setSearchOpen,
    }),
    [
      trips, trip, settings, route, toasts, storageError, dirty, tripModal, searchOpen, demoExists,
      navigate, setSettings, toast, dismissToast, saveNow,
      createTrip, updateTrip, openTrip, deleteTrip, duplicateTrip, clearTripData, clearAll,
      patchTrip, upsert, remove, openDemo, resetDemo, importText, exportTrip, exportAll,
      openTripModal, closeTripModal,
    ]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
